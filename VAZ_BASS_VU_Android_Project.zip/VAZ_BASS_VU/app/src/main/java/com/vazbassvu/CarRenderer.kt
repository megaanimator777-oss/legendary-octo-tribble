package com.vazbassvu

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class CarRenderer : GLSurfaceView.Renderer {
    @Volatile var white = false
    @Volatile var manualBass = .7f
    @Volatile var audioBass = 0f
    private var program = 0
    private var aPos = 0
    private var uColor = 0
    private var uMvp = 0
    private val projection = FloatArray(16)
    private val view = FloatArray(16)
    private val model = FloatArray(16)
    private val mv = FloatArray(16)
    private val mvp = FloatArray(16)
    private val cube = cubeVertices()
    private val buffer: FloatBuffer = ByteBuffer.allocateDirect(cube.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(cube); position(0) }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(.018f, .022f, .032f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        val vs = "attribute vec4 p; uniform mat4 m; void main(){gl_Position=m*p;}"
        val fs = "precision mediump float; uniform vec4 c; void main(){gl_FragColor=c;}"
        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, shader(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(program, shader(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(program)
        aPos = GLES20.glGetAttribLocation(program, "p")
        uColor = GLES20.glGetUniformLocation(program, "c")
        uMvp = GLES20.glGetUniformLocation(program, "m")
    }
    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h)
        Matrix.perspectiveM(projection, 0, 43f, w.toFloat() / h.coerceAtLeast(1), .1f, 100f)
    }
    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        Matrix.setLookAtM(view, 0, 0f, 2.3f, 8.7f, 0f, .2f, 0f, 0f, 1f, 0f)
        val body = if (white) floatArrayOf(.82f,.84f,.87f,1f) else floatArrayOf(.035f,.04f,.052f,1f)
        box(0f,-.42f,0f,4.5f,.7f,1.7f,body)
        box(0f,.12f,-.18f,3.55f,.85f,1.2f,body)
        // Rear opening / trunk interior
        box(0f,.03f,.88f,3.3f,1.05f,.12f,floatArrayOf(.008f,.01f,.015f,1f))
        box(0f,-.39f,.68f,3.05f,.16f,.3f,floatArrayOf(.12f,.13f,.15f,1f))
        box(0f,-.02f,.48f,2.35f,1.05f,.3f,floatArrayOf(.045f,.05f,.06f,1f))
        val pulse = (manualBass*.2f + audioBass*.9f).coerceIn(.08f,1f)
        box(0f,-.02f,.72f,1.85f,1.85f,.12f,floatArrayOf(.012f,.014f,.019f,1f))
        box(0f,-.02f,.83f+pulse*.08f,1.58f,1.58f,.1f,floatArrayOf(.16f,.17f,.19f,1f))
        box(0f,-.02f,.91f+pulse*.18f,1.26f,1.26f,.13f,floatArrayOf(.025f,.03f,.04f,1f))
        box(0f,-.02f,1.02f+pulse*.27f,.36f,.36f,.16f,floatArrayOf(.24f,.25f,.27f,1f))
        box(-1.8f,-.65f,.1f,.55f,.5f,.55f,floatArrayOf(.008f,.009f,.012f,1f))
        box(1.8f,-.65f,.1f,.55f,.5f,.55f,floatArrayOf(.008f,.009f,.012f,1f))
    }
    private fun box(x:Float,y:Float,z:Float,sx:Float,sy:Float,sz:Float,c:FloatArray) {
        Matrix.setIdentityM(model,0); Matrix.translateM(model,0,x,y,z); Matrix.scaleM(model,0,sx,sy,sz)
        Matrix.multiplyMM(mv,0,view,0,model,0); Matrix.multiplyMM(mvp,0,projection,0,mv,0)
        GLES20.glUseProgram(program); GLES20.glUniformMatrix4fv(uMvp,1,false,mvp,0); GLES20.glUniform4fv(uColor,1,c,0)
        GLES20.glEnableVertexAttribArray(aPos); buffer.position(0); GLES20.glVertexAttribPointer(aPos,3,GLES20.GL_FLOAT,false,0,buffer)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,cube.size/3); GLES20.glDisableVertexAttribArray(aPos)
    }
    private fun shader(type:Int,src:String):Int { val s=GLES20.glCreateShader(type); GLES20.glShaderSource(s,src); GLES20.glCompileShader(s); return s }
    companion object {
        private fun cubeVertices() = floatArrayOf(
            -.5f,-.5f,.5f, .5f,-.5f,.5f, .5f,.5f,.5f, -.5f,-.5f,.5f, .5f,.5f,.5f, -.5f,.5f,.5f,
            .5f,-.5f,-.5f, -.5f,-.5f,-.5f, -.5f,.5f,-.5f, .5f,-.5f,-.5f, -.5f,.5f,-.5f, .5f,.5f,-.5f,
            -.5f,-.5f,-.5f, -.5f,-.5f,.5f, -.5f,.5f,.5f, -.5f,-.5f,-.5f, -.5f,.5f,.5f, -.5f,.5f,-.5f,
            .5f,-.5f,.5f, .5f,-.5f,-.5f, .5f,.5f,-.5f, .5f,-.5f,.5f, .5f,.5f,-.5f, .5f,.5f,.5f,
            -.5f,.5f,.5f, .5f,.5f,.5f, .5f,.5f,-.5f, -.5f,.5f,.5f, .5f,.5f,-.5f, -.5f,.5f,-.5f,
            -.5f,-.5f,-.5f, .5f,-.5f,-.5f, .5f,-.5f,.5f, -.5f,-.5f,-.5f, .5f,-.5f,.5f, -.5f,-.5f,.5f
        )
    }
}
