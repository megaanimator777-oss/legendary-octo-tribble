package com.vazbassvu

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Visualizer
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var car: CarRenderer
    private var visualizer: Visualizer? = null
    private var boost: BassBoost? = null
    private var eq: Equalizer? = null
    private var enabled = false
    private var level = 70

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 9, 13)
        window.navigationBarColor = Color.rgb(8, 9, 13)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 8, 16, 8); setBackgroundColor(Color.rgb(8, 9, 13)) }
        root.addView(TextView(this).apply { text = "VAZ BASS VU  •  LIVE CAR AUDIO"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(Color.WHITE) })
        val scene = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2)
            car = CarRenderer()
            setRenderer(car)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
        root.addView(scene, LinearLayout.LayoutParams(-1, 0, 1f))
        val colors = LinearLayout(this).apply { gravity = Gravity.CENTER }
        colors.addView(Button(this).apply { text = "ЧЁРНАЯ"; setOnClickListener { car.white = false } })
        colors.addView(Button(this).apply { text = "БЕЛАЯ"; setOnClickListener { car.white = true } })
        root.addView(colors)
        val title = TextView(this).apply { text = "BASS BOOST • $level%"; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        root.addView(title)
        root.addView(SeekBar(this).apply {
            max = 100; progress = level
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { level = p; title.text = "BASS BOOST • $p%"; car.manualBass = p / 100f; applyEffects() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        root.addView(Button(this).apply { text = "ВКЛ / ВЫКЛ УСИЛЕНИЕ БАСА"; setOnClickListener { enabled = !enabled; applyEffects(); text = if (enabled) "УСИЛЕНИЕ ВКЛЮЧЕНО" else "УСИЛЕНИЕ ВЫКЛЮЧЕНО" } })
        setContentView(root)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startAnalysis()
        else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 42)
    }

    private fun startAnalysis() {
        try {
            visualizer = Visualizer(0).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1]
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer, data: ByteArray, rate: Int) {
                        var sum = 0f
                        for (b in data) sum += kotlin.math.abs(b.toInt() - 128)
                        car.audioBass = (sum / (data.size * 128f)).coerceIn(0f, 1f)
                    }
                    override fun onFftDataCapture(v: Visualizer, data: ByteArray, rate: Int) {
                        var sum = 0f
                        for (i in 2 until minOf(data.size, 30) step 2) sum += kotlin.math.abs(data[i].toInt())
                        car.audioBass = (sum / 1500f).coerceIn(0f, 1f)
                    }
                }, Visualizer.getMaxCaptureRate() / 2, true, true)
                enabled = true
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Анализ выходного звука недоступен для этой прошивки или плеера", Toast.LENGTH_LONG).show()
        }
    }

    private fun applyEffects() {
        try {
            if (boost == null) boost = BassBoost(0, 0)
            boost?.setStrength((level * 10).toShort())
            boost?.enabled = enabled
            if (eq == null) eq = Equalizer(0, 0)
            eq?.enabled = enabled
        } catch (_: Exception) {
            Toast.makeText(this, "Глобальный аудиоэффект не поддерживается устройством", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startAnalysis()
    }
    override fun onDestroy() {
        try { visualizer?.release(); boost?.release(); eq?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
